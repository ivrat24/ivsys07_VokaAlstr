"""实验 04 的本地课程代码。"""

from .paths import configure_local_sources

configure_local_sources()

__all__ = ["configure_local_sources"]
