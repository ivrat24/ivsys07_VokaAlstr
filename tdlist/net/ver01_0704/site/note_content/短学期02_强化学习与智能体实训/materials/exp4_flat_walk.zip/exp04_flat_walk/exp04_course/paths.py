"""实验 04 的本地路径配置。"""

from __future__ import annotations

import os
import sys
from pathlib import Path


EXP_ROOT = Path(__file__).resolve().parents[1]
LAB_ROOT = EXP_ROOT.parent
WORKSPACE_ROOT = LAB_ROOT.parent
MJLAB_ROOT = WORKSPACE_ROOT / "source" / "mjlab"


def configure_local_sources() -> None:
  """Put local source checkouts on ``sys.path`` for notebooks and scripts."""
  os.environ.setdefault("MUJOCO_GL", "glfw")
  os.environ.setdefault("MPLCONFIGDIR", str(EXP_ROOT / "outputs" / ".matplotlib"))
  os.environ.setdefault("WARP_CACHE_PATH", str(EXP_ROOT / "outputs" / ".warp"))
  Path(os.environ["MPLCONFIGDIR"]).mkdir(parents=True, exist_ok=True)
  Path(os.environ["WARP_CACHE_PATH"]).mkdir(parents=True, exist_ok=True)

  for path in (
    WORKSPACE_ROOT,
    EXP_ROOT,
    MJLAB_ROOT / "src",
    WORKSPACE_ROOT / "source" / "mujoco_warp",
  ):
    text = str(path)
    if text not in sys.path:
      sys.path.insert(0, text)


__all__ = [
  "EXP_ROOT",
  "LAB_ROOT",
  "MJLAB_ROOT",
  "WORKSPACE_ROOT",
  "configure_local_sources",
]
