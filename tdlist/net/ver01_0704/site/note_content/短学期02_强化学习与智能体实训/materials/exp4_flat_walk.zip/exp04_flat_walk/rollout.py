#!/usr/bin/env python3
"""运行实验 04 的短时零动作试运行。"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import torch

EXP_ROOT = Path(__file__).resolve().parent
if str(EXP_ROOT) not in sys.path:
  sys.path.insert(0, str(EXP_ROOT))

from exp04_course.paths import configure_local_sources

configure_local_sources()

import exp04_course.mjlab_tasks  # noqa: F401
from mjlab.envs import ManagerBasedRlEnv
from mjlab.tasks.registry import load_env_cfg


TASK_ID = "Course-G1-Flat-PPO"


def parse_args() -> argparse.Namespace:
  parser = argparse.ArgumentParser(description=__doc__)
  parser.add_argument("--num-envs", type=int, default=32)
  parser.add_argument("--steps", type=int, default=8)
  parser.add_argument("--device", default="cuda:0")
  return parser.parse_args()


def _resolve_device(requested: str) -> str:
  if requested.startswith("cuda") and not torch.cuda.is_available():
    raise RuntimeError(f"请求的设备为 {requested}，但当前 PyTorch 看不到 CUDA。")
  return requested


def main() -> None:
  args = parse_args()
  device = _resolve_device(args.device)
  cfg = load_env_cfg(TASK_ID)
  cfg.scene.num_envs = args.num_envs
  env = ManagerBasedRlEnv(cfg, device=device)
  try:
    env.reset()
    rewards = []
    terminated = torch.zeros(args.num_envs, dtype=torch.bool, device=device)
    truncated = torch.zeros(args.num_envs, dtype=torch.bool, device=device)
    for _ in range(args.steps):
      action = torch.zeros((args.num_envs, env.action_manager.total_action_dim), device=device)
      _obs, reward, terminated, truncated, _extras = env.step(action)
      rewards.append(float(reward.mean().detach().cpu()))
  finally:
    env.close()

  print(f"task={TASK_ID}")
  print(f"device={device}")
  print(f"num_envs={args.num_envs}")
  print(f"rollout_steps={args.steps}")
  print(f"mean_reward={sum(rewards) / max(1, len(rewards)):.4f}")
  print(f"terminated_any={bool(terminated.any().item())}")
  print(f"truncated_any={bool(truncated.any().item())}")


if __name__ == "__main__":
  main()
