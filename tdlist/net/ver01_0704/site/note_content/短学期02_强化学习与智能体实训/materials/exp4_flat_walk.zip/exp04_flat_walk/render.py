#!/usr/bin/env python3
"""尝试渲染实验 04 的一帧 RGB 图像。"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

EXP_ROOT = Path(__file__).resolve().parent
if str(EXP_ROOT) not in sys.path:
  sys.path.insert(0, str(EXP_ROOT))

from exp04_course.paths import configure_local_sources

configure_local_sources()

from exp04_course.visualization import save_rgb_frame, try_render_mjlab_frame


TASK_ID = "Course-G1-Flat-PPO"


def parse_args() -> argparse.Namespace:
  parser = argparse.ArgumentParser(description=__doc__)
  parser.add_argument("--device", default=None)
  parser.add_argument("--num-envs", type=int, default=1)
  parser.add_argument("--steps", type=int, default=1)
  parser.add_argument("--width", type=int, default=320)
  parser.add_argument("--height", type=int, default=240)
  parser.add_argument("--output", type=Path, default=EXP_ROOT / "outputs" / "visualizations" / "mjlab_render.png")
  parser.add_argument("--strict", action="store_true", help="如果 env.render() 不可用则返回失败状态")
  return parser.parse_args()


def main() -> None:
  args = parse_args()
  result = try_render_mjlab_frame(
    TASK_ID,
    num_envs=args.num_envs,
    steps=args.steps,
    device=args.device,
    width=args.width,
    height=args.height,
  )
  payload = {
    "ok": bool(result["ok"]),
    "device": result["device"],
    "message": result["message"],
    "output": None,
  }
  if result["ok"]:
    out = save_rgb_frame(args.output, result["frame"])
    payload["output"] = str(out)
  print(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))
  if args.strict and not result["ok"]:
    raise SystemExit(1)


if __name__ == "__main__":
  main()
