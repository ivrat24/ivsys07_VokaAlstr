# 实验 04：G1 平地行走 PPO

本实验只包含平地行走任务。实验代码位于 `exp04_course/`，入口脚本位于本文件夹根部，打开 `notebook.ipynb` 完成学习内容。

## 依赖安装

本实验依赖 `dependencies/mujoco_warp` 和 `dependencies/mjlab`。在运行 notebook 或脚本前，先在实训包根目录安装本地 editable 依赖：

```bash
conda activate summer
python -m pip install -U pip
python -m pip install -e dependencies/mujoco_warp
python -m pip install -e dependencies/mjlab
```

如果同时准备运行实验八，也可以按 `dependencies/README.md` 一次性安装全部本地依赖。

## 实现目标

目标不是“训练脚本能跑完”，而是训练出能跟踪速度指令的平地 G1 策略。

建议验收阈值：

- 策略在平地上保持站立并持续行走，不靠摔倒或站立刷奖励；
- 线速度跟踪误差目标：$\lVert v_{xy}^{cmd}-v_{xy}\rVert_2 \le 0.35\ \mathrm{m/s}$；
- 角速度跟踪误差目标：$|\omega_z^{cmd}-\omega_z| \le 0.25\ \mathrm{rad/s}$；
- 动作平滑项调大后，动作变化应下降；如果奖励上升但速度误差变大，需要重新平衡权重。

## 快速运行

```bash
cd path/to/lab-root
conda run -n summer python exp04_flat_walk/rollout.py --num-envs 32 --steps 8 --device cuda:0
conda run -n summer python exp04_flat_walk/train.py --num-envs 4096 --iterations 6 --steps-per-env 16 --gpu-id 0
```

渲染检查：

```bash
conda run -n summer python exp04_flat_walk/render.py
```

无显示环境中渲染检查会输出诊断信息，不影响试运行和训练入口。
