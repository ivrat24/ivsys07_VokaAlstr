#!/usr/bin/env python3
"""训练实验 04 的 G1 平地 PPO。"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import torch

EXP_ROOT = Path(__file__).resolve().parent
if str(EXP_ROOT) not in sys.path:
  sys.path.insert(0, str(EXP_ROOT))

from exp04_course.paths import configure_local_sources

configure_local_sources()

import exp04_course.mjlab_tasks  # noqa: F401
from mjlab.scripts.train import TrainConfig, launch_training
from mjlab.tasks.registry import load_env_cfg, load_rl_cfg


TASK_ID = "Course-G1-Flat-PPO"


def parse_args() -> argparse.Namespace:
  parser = argparse.ArgumentParser(description=__doc__)
  parser.add_argument("--num-envs", type=int, default=4096)
  parser.add_argument("--iterations", type=int, default=6)
  parser.add_argument("--steps-per-env", type=int, default=16)
  parser.add_argument("--gpu-id", type=int, default=0)
  parser.add_argument("--seed", type=int, default=7)
  parser.add_argument("--log-root", type=Path, default=EXP_ROOT / "outputs" / "rsl_rl")
  return parser.parse_args()


def main() -> None:
  args = parse_args()
  if not torch.cuda.is_available():
    raise RuntimeError("训练入口需要 CUDA；请在可见 cuda:0 的环境运行。")
  env_cfg = load_env_cfg(TASK_ID)
  agent_cfg = load_rl_cfg(TASK_ID)
  env_cfg.scene.num_envs = args.num_envs
  env_cfg.seed = args.seed
  agent_cfg.max_iterations = args.iterations
  agent_cfg.num_steps_per_env = args.steps_per_env
  agent_cfg.save_interval = max(1, args.iterations)
  agent_cfg.logger = "tensorboard"
  agent_cfg.upload_model = False
  agent_cfg.run_name = f"flat_{args.num_envs}_envs"
  cfg = TrainConfig(
    env=env_cfg,
    agent=agent_cfg,
    log_root=str(args.log_root),
    gpu_ids=[args.gpu_id],
  )
  launch_training(task_id=TASK_ID, args=cfg)


if __name__ == "__main__":
  main()
