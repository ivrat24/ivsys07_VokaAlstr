"""Visualization helpers for the course notebooks and scripts."""

from __future__ import annotations

import contextlib
import io
import os
from pathlib import Path
from typing import Any

import numpy as np

from exp04_course.paths import configure_local_sources

configure_local_sources()


@contextlib.contextmanager
def _quiet(enabled: bool = True):
  if not enabled:
    yield
    return
  with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
    yield


def reward_weights_from_cfg(cfg: Any) -> dict[str, float]:
  """Extract reward weights from an mjlab env config."""
  rewards = getattr(cfg, "rewards", {})
  return {
    name: float(getattr(term, "weight", np.nan))
    for name, term in rewards.items()
  }


def plot_reward_weights(weights_or_cfg: Any, title: str = "Reward weights"):
  """Plot reward weights as a compact horizontal bar chart."""
  import matplotlib.pyplot as plt

  if not isinstance(weights_or_cfg, dict):
    weights = reward_weights_from_cfg(weights_or_cfg)
  else:
    weights = {str(k): float(v) for k, v in weights_or_cfg.items()}
  names = list(weights)
  values = np.asarray([weights[name] for name in names], dtype=np.float32)
  colors = np.where(values >= 0.0, "#2f80ed", "#d1495b")

  fig_height = max(3.5, 0.28 * len(names))
  fig, ax = plt.subplots(figsize=(8, fig_height))
  ax.barh(names, values, color=colors)
  ax.axvline(0.0, color="#333333", linewidth=0.8)
  ax.set_xlabel("weight")
  ax.set_title(title)
  ax.grid(axis="x", alpha=0.25)
  fig.tight_layout()
  return fig, ax


def _stage_value(value: Any) -> float:
  if isinstance(value, (tuple, list)):
    arr = np.asarray(value, dtype=np.float32)
    return float(np.max(np.abs(arr)))
  return float(value)


def plot_command_schedule(stages: list[dict[str, Any]], title: str = "Command curriculum"):
  """Plot the per-stage command magnitudes used by the rough-terrain lab."""
  import matplotlib.pyplot as plt

  if not stages:
    raise ValueError("stages must contain at least one command stage")

  steps = [int(stage.get("step", idx)) for idx, stage in enumerate(stages)]
  keys = [key for key in stages[0] if key != "step"]
  fig, ax = plt.subplots(figsize=(8, 4))
  for key in keys:
    values = [_stage_value(stage[key]) for stage in stages]
    ax.step(steps, values, where="post", linewidth=2.0, label=key)
    ax.scatter(steps, values, s=24)
  ax.set_xlabel("global step")
  ax.set_ylabel("max absolute command")
  ax.set_title(title)
  ax.grid(alpha=0.25)
  ax.legend(loc="best")
  fig.tight_layout()
  return fig, ax


def plot_rollout_rewards(rewards: list[float] | np.ndarray, title: str = "Rollout rewards"):
  """Plot mean reward over a short rollout."""
  import matplotlib.pyplot as plt

  rewards = np.asarray(rewards, dtype=np.float32)
  fig, ax = plt.subplots(figsize=(7, 3.5))
  ax.plot(np.arange(len(rewards)), rewards, marker="o", color="#087e8b")
  ax.set_xlabel("step")
  ax.set_ylabel("mean reward")
  ax.set_title(title)
  ax.grid(alpha=0.25)
  fig.tight_layout()
  return fig, ax


def collect_mjlab_rollout_trace(
  task_id: str,
  *,
  num_envs: int = 1,
  steps: int = 4,
  device: str | None = None,
  quiet: bool = True,
) -> dict[str, Any]:
  """Run a tiny zero-action mjlab rollout and return a plotting-friendly trace."""
  import torch
  import exp04_course.mjlab_tasks  # noqa: F401
  from mjlab.envs import ManagerBasedRlEnv
  from mjlab.tasks.registry import load_env_cfg

  resolved_device = device or ("cuda:0" if torch.cuda.is_available() else "cpu")
  if resolved_device.startswith("cuda") and not torch.cuda.is_available():
    resolved_device = "cpu"

  env = None
  rewards: list[float] = []
  terminated_any = False
  truncated_any = False
  with _quiet(quiet):
    try:
      cfg = load_env_cfg(task_id)
      cfg.scene.num_envs = int(num_envs)
      env = ManagerBasedRlEnv(cfg, device=resolved_device)
      env.reset()
      for _ in range(int(steps)):
        action = torch.zeros(
          (int(num_envs), env.action_manager.total_action_dim),
          device=resolved_device,
        )
        _obs, reward, terminated, truncated, _extras = env.step(action)
        rewards.append(float(reward.mean().detach().cpu()))
        terminated_any = terminated_any or bool(terminated.any().item())
        truncated_any = truncated_any or bool(truncated.any().item())
    finally:
      if env is not None:
        env.close()

  return {
    "task_id": task_id,
    "device": resolved_device,
    "num_envs": int(num_envs),
    "steps": int(steps),
    "rewards": rewards,
    "mean_reward": float(np.mean(rewards)) if rewards else 0.0,
    "terminated_any": terminated_any,
    "truncated_any": truncated_any,
  }


def try_render_mjlab_frame(
  task_id: str,
  *,
  num_envs: int = 1,
  steps: int = 1,
  device: str | None = None,
  width: int = 320,
  height: int = 240,
  quiet: bool = True,
) -> dict[str, Any]:
  """Try mjlab's real ``env.render()`` path and return a frame or a diagnostic."""
  import torch
  import exp04_course.mjlab_tasks  # noqa: F401
  from mjlab.envs import ManagerBasedRlEnv
  from mjlab.tasks.registry import load_env_cfg

  resolved_device = device or ("cuda:0" if torch.cuda.is_available() else "cpu")
  if resolved_device.startswith("cuda") and not torch.cuda.is_available():
    resolved_device = "cpu"

  gl_backend = os.environ.get("MUJOCO_GL", "glfw").lower()
  if gl_backend == "glfw":
    try:
      import glfw

      if not glfw.init():
        return {
          "ok": False,
          "frame": None,
          "device": resolved_device,
          "message": "GLFW could not initialize a display; run on a workstation display or configure EGL/X11.",
        }
      glfw.terminate()
    except Exception as exc:  # noqa: BLE001 - render preflight should not stop notebooks.
      return {
        "ok": False,
        "frame": None,
        "device": resolved_device,
        "message": f"GLFW preflight failed: {type(exc).__name__}: {exc}",
      }

  env = None
  try:
    with _quiet(quiet):
      cfg = load_env_cfg(task_id)
      cfg.scene.num_envs = int(num_envs)
      cfg.viewer.width = int(width)
      cfg.viewer.height = int(height)
      cfg.viewer.env_idx = 0
      cfg.viewer.max_extra_envs = 0
      env = ManagerBasedRlEnv(cfg, device=resolved_device, render_mode="rgb_array")
      env.reset()
      for _ in range(int(steps)):
        action = torch.zeros(
          (int(num_envs), env.action_manager.total_action_dim),
          device=resolved_device,
        )
        env.step(action)
      frame = env.render()
    if frame is None:
      return {
        "ok": False,
        "frame": None,
        "device": resolved_device,
        "message": "env.render() returned None",
      }
    return {
      "ok": True,
      "frame": np.asarray(frame),
      "device": resolved_device,
      "message": f"rendered {int(width)}x{int(height)} rgb_array frame",
    }
  except Exception as exc:  # noqa: BLE001 - notebooks need a non-crashing diagnostic.
    return {
      "ok": False,
      "frame": None,
      "device": resolved_device,
      "message": f"{type(exc).__name__}: {exc}",
    }
  finally:
    if env is not None:
      with contextlib.suppress(Exception):
        env.close()


def collect_navigation_trajectory(env: Any, policy: Any, steps: int = 80) -> dict[str, Any]:
  """Roll out one terrain-navigation policy and keep env-0 positions for plotting."""
  obs = env.reset()
  trajectory = [env.positions[0].copy()]
  rewards: list[float] = []
  done = False
  for _ in range(int(steps)):
    if hasattr(policy, "predict"):
      actions = policy.predict(obs)
    else:
      actions = policy(obs)
    obs, reward, done_batch, _info = env.step(actions)
    trajectory.append(env.positions[0].copy())
    rewards.append(float(reward[0]))
    done = bool(done_batch[0])
    if done:
      break
  return {
    "trajectory": np.asarray(trajectory, dtype=np.float32),
    "rewards": rewards,
    "done": done,
    "metrics": env.metrics(),
  }


def plot_navigation_route(
  env: Any,
  trajectory: np.ndarray | None = None,
  *,
  title: str = "Terrain route and policy trace",
  max_faces: int = 20000,
):
  """Plot terrain height, route, start/goal, and an optional policy trace."""
  import matplotlib.pyplot as plt

  mesh = env.scene.mesh
  vertices = np.asarray(mesh.vertices)
  faces = np.asarray(mesh.faces)
  if len(faces) == 0:
    raise ValueError("navigation scene mesh has no faces")

  centers = vertices[faces].mean(axis=1)
  stride = max(1, int(np.ceil(len(centers) / max_faces)))
  centers = centers[::stride]

  fig, ax = plt.subplots(figsize=(7, 6))
  scatter = ax.scatter(
    centers[:, 0],
    centers[:, 1],
    c=centers[:, 2],
    s=2,
    cmap="terrain",
    alpha=0.8,
    linewidths=0,
  )
  route = np.asarray(env.route)
  ax.plot(route[:, 0], route[:, 1], color="#1f1f1f", linewidth=2.2, label="planned route")
  ax.scatter(route[0, 0], route[0, 1], color="#2ca02c", s=70, marker="o", label="start")
  ax.scatter(route[-1, 0], route[-1, 1], color="#d62728", s=90, marker="*", label="goal")
  if trajectory is not None and len(trajectory):
    trajectory = np.asarray(trajectory)
    ax.plot(trajectory[:, 0], trajectory[:, 1], color="#ff7f0e", linewidth=2.0, label="policy trace")
    ax.scatter(trajectory[-1, 0], trajectory[-1, 1], color="#ff7f0e", s=45)
  ax.set_aspect("equal", adjustable="box")
  ax.set_xlabel("x (m)")
  ax.set_ylabel("y (m)")
  ax.set_title(title)
  ax.legend(loc="best")
  fig.colorbar(scatter, ax=ax, fraction=0.046, pad=0.04, label="height (m)")
  fig.tight_layout()
  return fig, ax


def plot_navigation_metrics(metrics: dict[str, float], title: str = "Navigation metrics"):
  """Plot the final-project evaluator metrics."""
  import matplotlib.pyplot as plt

  keys = ["success_rate", "mean_progress", "mean_illegal_collisions"]
  values = [float(metrics.get(key, 0.0)) for key in keys]
  fig, ax = plt.subplots(figsize=(7, 3.5))
  ax.bar(keys, values, color=["#2ca02c", "#1f77b4", "#d62728"])
  ax.set_title(title)
  ax.grid(axis="y", alpha=0.25)
  fig.tight_layout()
  return fig, ax


def save_rgb_frame(path: str | Path, frame: np.ndarray) -> Path:
  """Save an RGB frame with matplotlib, avoiding an extra image dependency."""
  import matplotlib.pyplot as plt

  out = Path(path)
  out.parent.mkdir(parents=True, exist_ok=True)
  plt.imsave(out, np.asarray(frame, dtype=np.uint8))
  return out
