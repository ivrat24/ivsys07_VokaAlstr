"""PPO configs for the humanoid course labs."""

from __future__ import annotations

from mjlab.rl import (
  RslRlModelCfg,
  RslRlOnPolicyRunnerCfg,
  RslRlPpoAlgorithmCfg,
)


def course_g1_ppo_runner_cfg(experiment_name: str) -> RslRlOnPolicyRunnerCfg:
  """Return the default PPO config for the course humanoid labs."""
  return RslRlOnPolicyRunnerCfg(
    actor=RslRlModelCfg(
      hidden_dims=(256, 128),
      activation="elu",
      obs_normalization=True,
      distribution_cfg={
        "class_name": "GaussianDistribution",
        "init_std": 0.8,
        "std_type": "scalar",
      },
    ),
    critic=RslRlModelCfg(
      hidden_dims=(256, 128),
      activation="elu",
      obs_normalization=True,
    ),
    algorithm=RslRlPpoAlgorithmCfg(
      value_loss_coef=1.0,
      use_clipped_value_loss=True,
      clip_param=0.2,
      entropy_coef=0.01,
      num_learning_epochs=2,
      num_mini_batches=2,
      learning_rate=1.0e-3,
      schedule="adaptive",
      gamma=0.99,
      lam=0.95,
      desired_kl=0.02,
      max_grad_norm=1.0,
    ),
    experiment_name=experiment_name,
    run_name="classroom",
    logger="tensorboard",
    upload_model=False,
    save_interval=5,
    num_steps_per_env=16,
    max_iterations=6,
  )
