"""Experiment 04 flat-ground mjlab environment configuration."""

from __future__ import annotations

from mjlab.envs import ManagerBasedRlEnvCfg
from mjlab.tasks.velocity.config.g1.env_cfgs import unitree_g1_flat_env_cfg
from mjlab.tasks.velocity.mdp import UniformVelocityCommandCfg

from .safe_events import reset_joints_by_offset_batched


def _course_training_env(cfg: ManagerBasedRlEnvCfg) -> ManagerBasedRlEnvCfg:
  cfg.scene.num_envs = 4096
  cfg.scene.extent = 1.8
  cfg.episode_length_s = 8.0
  cfg.seed = 7
  cfg.scale_rewards_by_dt = True
  cfg.events["reset_robot_joints"].func = reset_joints_by_offset_batched
  return cfg


def course_g1_flat_env_cfg(play: bool = False) -> ManagerBasedRlEnvCfg:
  """Flat-ground G1 walking task with ordinary velocity-tracking rewards."""
  cfg = _course_training_env(unitree_g1_flat_env_cfg(play=play))

  twist_cmd = cfg.commands["twist"]
  assert isinstance(twist_cmd, UniformVelocityCommandCfg)
  twist_cmd.ranges.lin_vel_x = (0.15, 0.9)
  twist_cmd.ranges.lin_vel_y = (-0.15, 0.15)
  twist_cmd.ranges.ang_vel_z = (-0.35, 0.35)
  twist_cmd.rel_standing_envs = 0.0
  twist_cmd.rel_forward_envs = 0.65
  twist_cmd.resampling_time_range = (2.0, 5.0)

  cfg.rewards["track_linear_velocity"].weight = 2.5
  cfg.rewards["track_angular_velocity"].weight = 1.2
  cfg.rewards["pose"].weight = 0.6
  cfg.rewards["action_rate_l2"].weight = -0.06

  cfg.curriculum = {}
  if play:
    cfg.scene.num_envs = 4
    cfg.episode_length_s = 20.0
  return cfg
