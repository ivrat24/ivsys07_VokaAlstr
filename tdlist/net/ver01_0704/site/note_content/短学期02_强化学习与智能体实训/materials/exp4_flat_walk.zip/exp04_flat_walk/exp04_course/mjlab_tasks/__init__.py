"""注册实验 04 的 mjlab 任务。"""

from mjlab.tasks.registry import register_mjlab_task
from mjlab.tasks.velocity.rl import VelocityOnPolicyRunner

from .env_cfgs import course_g1_flat_env_cfg
from .rl_cfg import course_g1_ppo_runner_cfg


register_mjlab_task(
  task_id="Course-G1-Flat-PPO",
  env_cfg=course_g1_flat_env_cfg(),
  play_env_cfg=course_g1_flat_env_cfg(play=True),
  rl_cfg=course_g1_ppo_runner_cfg("course_g1_flat"),
  runner_cls=VelocityOnPolicyRunner,
)
